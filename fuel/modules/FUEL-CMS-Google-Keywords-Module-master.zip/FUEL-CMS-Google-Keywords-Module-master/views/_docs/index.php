<h1>Google Keywords Module Documentation</h1>
<p>This Google Keywords module documentation is for version <?=GOOGLE_KEYWORDS_VERSION?>.</p>

<h2>Overview</h2>
<p>The Google Keywords module allows you to search a given domain with certain keywords to find out how highly you rank in the top 100.</p>

<?=generate_config_info()?>

<?=generate_toc()?>
