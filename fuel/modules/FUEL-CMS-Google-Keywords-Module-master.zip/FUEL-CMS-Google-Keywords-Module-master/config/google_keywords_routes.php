<?php 
$route[FUEL_ROUTE.'tools/google_keywords'] = 'google_keywords';