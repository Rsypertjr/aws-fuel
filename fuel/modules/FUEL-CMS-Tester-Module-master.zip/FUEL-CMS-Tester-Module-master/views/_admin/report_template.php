<table border="0" cellpadding="0" cellspacing="0" class="test_results">
    {rows}
        <tr>
        <td class="item">{item}</td>
        <td class="result">{result}</td>
        </tr>
    {/rows}
</table>
<br />