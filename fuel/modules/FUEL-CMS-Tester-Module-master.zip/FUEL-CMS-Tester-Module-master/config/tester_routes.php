<?php 
$route[FUEL_ROUTE.'tools/tester'] = 'tester';
$route[FUEL_ROUTE.'tools/tester/(.+)'] = 'tester/$1';
